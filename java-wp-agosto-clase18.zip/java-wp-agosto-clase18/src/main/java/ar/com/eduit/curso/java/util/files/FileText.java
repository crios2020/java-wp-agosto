package ar.com.eduit.curso.java.util.files;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/*
 * Implementación para leer y escribir archivos de texto (caracter)
 */
public class FileText implements I_File {

    private File file;

    public FileText(File file) {
        this.file = file;
    }

    public FileText(String file){
        this.file = new File(file);
    }

    @Override
    public String getText() {
        //String texto="";
        StringBuffer sb=new StringBuffer();
        int car;

        try (FileReader in=new FileReader(file)) {
            while((car=in.read())!=-1){
                //texto+=(char)car;
                sb.append((char)car);
            }                     
        } catch (Exception e) {
            System.out.println(e);
        }
        //return texto;
        return sb.toString();
    }

    @Override
    public void setText(String text) {
        //try (FileOutputStream out=new FileOutputStream(file)) {        //stream de byte
        try (FileWriter out=new FileWriter(file)) {                     //stream de caracter
            out.write(text);                                            //stream de caracter
            //out.write(text.getBytes());                               //stream de byte
            //Java 6 incorporo el paquete NIO que permite escrituras concurrentes
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void append(String text) {
        try (FileWriter out=new FileWriter(file,true)) {   //abrimos el stream para agregar                  
            out.write(text);                             
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public List<String> getAll() {
        List<String>list=new ArrayList();
        try (BufferedReader in=new BufferedReader(new FileReader(file))){
            list=in.lines().toList();
        } catch (Exception e) {
            
        }
        return list;
    }
    
}
