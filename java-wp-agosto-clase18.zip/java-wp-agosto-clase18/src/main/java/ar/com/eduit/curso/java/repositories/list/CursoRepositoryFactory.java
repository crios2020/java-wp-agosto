package ar.com.eduit.curso.java.repositories.list;

public class CursoRepositoryFactory {
    private static CursoRepository cr=new CursoRepository();
    private CursoRepositoryFactory(){}
    public static CursoRepository getCursoRepository(){
        return cr;
    }
}
