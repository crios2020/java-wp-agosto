package ar.com.eduit.curso.java.connectors;

public class Connector {
	private static String driver="org.mariadb.jdbc.Driver";
	//private static String driver="com.mysql.cj.jdbc.Driver";
	
	
}
