package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Auto;

public class TestStatic {
	public static void main(String[] args) {

		Auto.acelerar(); 					//10
		
		Auto auto1=new Auto("Citroen","C4","Bordo");
		System.out.println(auto1);
		
		Auto.acelerar(); 					//20
		
		Auto auto2=new Auto("Ford","Ka","Negro");
		System.out.println(auto2);
		
		Auto.acelerar(); 					//30
		System.out.println(Auto.getVelocidad());
		
		
		//TODO interfaces
	}
}
