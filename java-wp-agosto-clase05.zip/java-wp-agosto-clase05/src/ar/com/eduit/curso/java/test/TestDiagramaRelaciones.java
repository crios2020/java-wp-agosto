package ar.com.eduit.curso.java.test;

import java.util.ArrayList;

import ar.com.eduit.curso.java.entities.ClienteEmpresa;
import ar.com.eduit.curso.java.entities.ClientePersona;
import ar.com.eduit.curso.java.entities.Cuenta;

public class TestDiagramaRelaciones {
	public static void main(String[] args) {
		
		//La clase cuenta esta encapsulada
		
		//Objetos Mocks o Objetos simulados
		System.out.println("-- cuenta1 --");
		Cuenta cuenta1=new Cuenta(1,"arg$");
		cuenta1.depositar(40000);
		cuenta1.depositar(80000);
		cuenta1.debitar(20000);
		//cuenta1.saldo=20000000;
		System.out.println(cuenta1);
		
		System.out.println("-- clientePersona1 --");
		ClientePersona clientePersona1=new ClientePersona(1,"Joaquin",34,cuenta1);
		clientePersona1.getCuenta().depositar(50000);
		System.out.println(clientePersona1);
		
		System.out.println("-- ana y juan --");
		ClientePersona ana=new ClientePersona(2,"ana",40,new Cuenta(2,"arg$"));
		ana.getCuenta().depositar(200000);
		ClientePersona juan=new ClientePersona(3,"juan",40,ana.getCuenta());
		juan.getCuenta().debitar(50000);
		System.out.println(ana);
		System.out.println(juan);
		
		System.out.println("-- clientePersona2 --");
		ClientePersona clientePersona2=new ClientePersona(4,"Rafael",47,3);
		clientePersona2.getCuenta().depositar(75000);
		System.out.println(clientePersona2);
		
		System.out.println("-- clienteEmpresa1 --");
		ClienteEmpresa clienteEmpresa1=new ClienteEmpresa(1,"Tienda Cafe","Lima 222");
		ArrayList<Cuenta>cuentas=clienteEmpresa1.getCuentas();
		cuentas.add(new Cuenta(10,"arg$"));				//0
		cuentas.add(new Cuenta(11,"reales"));			//1
		cuentas.add(new Cuenta(12,"U$S"));				//2
		cuentas.get(0).depositar(300000);
		cuentas.get(0).depositar(700000);
		cuentas.get(0).debitar(100000);
		cuentas.get(1).depositar(50000);
		cuentas.get(2).depositar(12000);
		System.out.println(clienteEmpresa1);
		
		
		
		
	}
}
