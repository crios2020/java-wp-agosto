package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.entities.Cuenta;
import ar.com.eduit.curso.java.entities.Direccion;
import ar.com.eduit.curso.java.entities.Persona;
import ar.com.eduit.curso.java.entities.Vendedor;

public class TestDiagramaHerencia {

	public static void main(String[] args) {
		System.out.println("-- dir1 --");
		Direccion dir1=new Direccion("Belgrano", 45, null, null, "Morón");
		System.out.println(dir1);
		
		System.out.println("-- dir2 --");
		Direccion dir2=new Direccion("Lima", 222,"4","e");
		System.out.println(dir2);
		
		
		//System.out.println("-- persona1 --");
		//Persona persona1=new Persona("Lorena",26,dir1);
		
		System.out.println("-- vendedor1 --");
		Vendedor vendedor1=new Vendedor("Lautaro",48,dir1, 1, 250000);
		System.out.println(vendedor1);
		vendedor1.reir();
		vendedor1.saludar();
		
		System.out.println("-- cliente1 --");
		Cliente cliente1=new Cliente("Matias",38,dir2,1,new Cuenta(1,"arg$"));
		cliente1.getCuenta().depositar(200000);
		System.out.println(cliente1);
		cliente1.reir();
		cliente1.saludar();
		
		//Polimorfismo - Poliformismo
		System.out.println("-- polimorfismo --");
		Persona p1=new Vendedor("Hernan",39, dir1, 2, 300000);
		Persona p2=new Cliente("Ana",29,dir2,2,new Cuenta(2,"arg$"));
		p1.saludar();
		p2.saludar();
		
		Object o;
		o=4;
		o="Hola";
		o=p1;
		
		Vendedor v1=(Vendedor)p1;
		Vendedor v2=(p1 instanceof Vendedor)?(Vendedor)p1:null;
		
		System.out.println(v1.getClass());
		System.out.println(v1.getClass().getName());
		System.out.println(v1.getClass().getSimpleName());
		System.out.println(v1.getClass().getSuperclass().getName());
		System.out.println(v1.getClass().getSuperclass().getSuperclass().getName());
		System.out.println(v1.getClass().getSuperclass().getSuperclass().getSuperclass());
		
		String s1="Hola";
		System.out.println(s1.getClass().getName());
		System.out.println(s1.getClass().getSuperclass().getName());
		
		Persona x;
		
		//static
		
		
		//TODO Interfaces
		
		
		
	}

}
