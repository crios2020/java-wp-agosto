package ar.com.eduit.curso.java.test;

public class TestHolaMundo {

	public static void main(String[] args) {
		System.out.println("Hola Mundo!");
	}

}
