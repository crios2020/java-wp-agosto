package ar.com.eduit.curso.java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


public class JavaWpAgostoClase10Application {

	public static void main(String[] args) {
		SpringApplication.run(JavaWpAgostoClase10Application.class, args);
	}

}
