package ar.com.eduit.curso.java.test;

//import java.util.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

import ar.com.eduit.curso.java.entities.Auto;

public class TestCollection {
	public static void main(String[] args) {
		
		//Array o vector
		Auto[] autos=new Auto[4];
		autos[0]=new Auto("Fiat","Uno","Blanco");
		autos[1]=new Auto("VW","Gol","Gris");
		autos[2]=new Auto("Renault","Fluence","Verde");
		autos[3]=new Auto("Toyota","Corolla","Rojo");
		
		//Recorrido con indices
		//for(int a=0; a<autos.length; a++) System.out.println(autos[a]);
		
		//Recorrido con forEach jdK 5 o sup
		//for(Auto auto:autos) System.out.println(auto);
		List.of(autos).forEach(System.out::println);
		
		//Interface List
		List list1;					//Tipo Object
		list1=new ArrayList();
		//list1=new LinkedList();
		//list1=new Vector();
		
		list1.add(new Auto("Citroen","C4","Bordo"));		// 0
		list1.add(new Auto("Chevrolet","Corsa","Negro"));	// 1
		list1.add("hola");									// 2
		list1.add("chau");									// 3
		list1.add(38);										// 4
		System.out.println(list1.get(2));
		list1.add(2,"Java");
		System.out.println(list1.get(2));
		System.out.println(list1.get(3));
		list1.remove(3);
		System.out.println(list1.get(3));
		
		//Copiar los autos de vector autos a list1
		//for(Auto a: autos) list1.add(a);
		list1.addAll(List.of(autos));
		
		System.out.println("*******************************************");
		//Recorrido con indices
		//for(int a=0; a<list1.size();a++) System.out.println(list1.get(a));
		
		//Recorrido forEach
		//for(Object o:list1) System.out.println(o);
		
		//Método forEach JDK 8 o sup
		//list1.forEach(o->System.out.println(o));
		//list1.forEach(o->{
		//	System.out.println(o);
		//});
		list1.forEach(System.out::println);
		
		
		//Uso de Generics <> JDK 5 sup
		List<Auto>list2=new ArrayList();			//Tipo Auto
		list2.add(new Auto("Peugeot","308","Azul"));
		
		Auto auto1=(Auto)list1.get(0);
		Auto auto2=list2.get(0);
		
		//Copiar los autos de list1 a list2
		list1.forEach(o->{
			if(o instanceof Auto) list2.add((Auto)o);
		});
		
		System.out.println("****************************************************");
		list2.forEach(System.out::println);
		
		//Pregunta de clase
		//System.out.println(list1.get(0).getClass());
		//System.out.println(list1.get(3).getClass());
		
		
		//Interface Set: Representa una lista sin indices y sin duplicados
		Set<String>set;
		
		//Implementación HashSet(): es la más veloz, pero no garantiza el orden de los elementos
		//set=new HashSet();
		
		//Implementación LinkedHashSet(): almacena elementos en una lista enlazada por orden de ingreso
		//set=new LinkedHashSet();
		
		//Implementación Treeset(): almacena elementos en un arbol balanceado por orden natural.
		set=new TreeSet();
		
		//app
		set.add("Lunes");
		set.add("Martes");
		set.add("Miércoles");
		set.add("Jueves");
		set.add("Lunes");
		set.add("Viernes");
		set.add("Sábado");
		set.add("Domingo");
		set.add("Martes");
		set.forEach(System.out::println);
		
		//Set Autos
		Set<Auto>setAutos;
		//setAutos=new LinkedHashSet();
		setAutos=new TreeSet();
		setAutos.addAll(list2);
		setAutos.add(new Auto("Toyota","Corolla","Rojo"));
		setAutos.add(new Auto("Toyota","Corolla","Verde"));
		setAutos.add(new Auto("Toyota","Corolla","Blanco"));
		setAutos.add(new Auto("Toyota","Corolla","Azul"));
		setAutos.add(new Auto("Toyota","Prius","Rojo"));
		setAutos.add(new Auto("Toyota","Etios","Rojo"));
		System.out.println("***************************************************");
		setAutos.forEach(auto->System.out.println(auto+"\t"+auto.hashCode()));
		
		
		//TODO Pilas Colas
		//TODO Interface Map
		
		
	}
}
