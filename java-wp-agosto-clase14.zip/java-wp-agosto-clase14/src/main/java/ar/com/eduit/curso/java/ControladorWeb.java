package ar.com.eduit.curso.java;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ControladorWeb {
    
    @GetMapping("/")
    public String index(){
        return "index";
    }

    @GetMapping("/alumnos")
    public String alumnos(){
        return "alumnos";
    }

    @GetMapping("/cursos")
    public String cursos(){
        return "cursos";
    }
}
