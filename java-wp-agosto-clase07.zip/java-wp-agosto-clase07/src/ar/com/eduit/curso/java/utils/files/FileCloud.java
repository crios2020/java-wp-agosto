package ar.com.eduit.curso.java.utils.files;

import ar.com.eduit.curso.java.interfaces.I_File;

public class FileCloud implements I_File{

	@Override
	public void setText(String text) {
		System.out.println("Escribiendo Archivo de nube!");
	}

	@Override
	public String getText() {
		return "Leyendo Archivo de nube!";
	}

}
