package ar.com.eduit.curso.java.entities;

import ar.com.eduit.curso.java.exceptions.NoHayMasPasajesException;

public class Vuelo {
	
	private String nombre;
	private int cantidadPasajesDisponibles;
	
	public Vuelo(String nombre, int cantidadPasajesDisponibles) {
		this.nombre = nombre;
		this.cantidadPasajesDisponibles = cantidadPasajesDisponibles;
	}

	public synchronized void venderPasajes(int cantidadPasajesPedidos) throws NoHayMasPasajesException {
		if (cantidadPasajesPedidos>cantidadPasajesDisponibles) {
			throw new NoHayMasPasajesException(nombre,cantidadPasajesDisponibles,cantidadPasajesPedidos);
		}
		cantidadPasajesDisponibles-=cantidadPasajesPedidos;
	}
	
	@Override
	public String toString() {
		return "Vuelo [nombre=" + nombre + ", cantidadPasajesDisponibles=" + cantidadPasajesDisponibles + "]";
	}

	public String getNombre() {
		return nombre;
	}

	public int getCantidadPasajesDisponibles() {
		return cantidadPasajesDisponibles;
	}
	
}
