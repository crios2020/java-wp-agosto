package ar.com.eduit.curso.java.test;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import ar.com.eduit.curso.java.entities.Vuelo;
import ar.com.eduit.curso.java.exceptions.NoHayMasPasajesException;
import ar.com.eduit.curso.java.generador.GeneradorExceptions;

public class TestExceptions {
	public static void main(String[] args) {
		
		//System.out.println(10/0);
		//System.out.println("Esta sentencia no se ejecuta!!!");
	
		/*
		 * 	Estructura try - catch - finally
		 * 
		 * try {							//Obligatorio
		 * 
		 * 		//Colocar aquí las sentencias que pueden arrojar una exception.
		 * 		//Estas sentencias tienen un costo mayor de hardware.
		 * 		//Si se puede ejecutar todo bien sin exceptions el bloque termina normalmente
		 * 		//Si ocurre una excpetion el bloque no termina y pasa el control al bloque catch
		 * } catch(Exception e){			//Obligatorio
		 * 		//El bloque catch se ejecuta en caso de error.
		 * 		//Se recibe como parámetro un Objeto de Exception.
		 * } finally {						//Opcional
		 * 		//Este bloque se ejecuta siémpre.
		 * 		//Las variables creadas en try o catch estan fuera de alcance(Scope)
		 * }
		 * 
		 *	//El programa termina normalmente 
		 * 
		 */
		/*
		try {
			System.out.println(10/1);
			System.out.println("Termina el bloque TRY!!!");
		} catch (Exception e) {
			System.out.println("Ocurrio un error!");
			System.out.println(e);
		} finally {
			System.out.println("El programa termina normalmente!");
		}
		*/
		
		/*
		try {
			System.out.println("Clase 07");
			//GeneradorExceptions.generar();
			//GeneradorExceptions.generar(true);
			//GeneradorExceptions.generar("38x");
			//GeneradorExceptions.generar(null,2);
			//GeneradorExceptions.generar("hola",20);
		} catch (Exception e) {
			System.out.println(e);
		}
		*/
		
		//Checked Exceptions
//		try {
//			FileReader reader=new FileReader("texto.txt");
//		} catch (FileNotFoundException e1) {
//			//e1.printStackTrace();
//			System.out.println(e1);
//			System.out.println(e1.getMessage());
//			System.out.println(e1.getLocalizedMessage());
//		}
		
		//Unchecked Exceptions
		//GeneradorExceptions.generar(true);
		
		
		//Captura personalizada de Exceptions
		try {
			//GeneradorExceptions.generar();
			//GeneradorExceptions.generar(true);
			//GeneradorExceptions.generar("26x");
			//GeneradorExceptions.generar(null,2);
			//GeneradorExceptions.generar("Hola",20);
			FileReader reader=new FileReader("texto.txt");
			System.out.println(reader.read());
		} catch (ArithmeticException e) 			{ System.out.println("División / 0");
		//} catch (ArrayIndexOutOfBoundsException e) 	{ System.out.println("Indice fuera de rango!");
		} catch (NumberFormatException e) 			{ System.out.println("Formato de número incorrecto!");
		} catch (NullPointerException e) 			{ System.out.println("Puntero Nulo!");
		//} catch (StringIndexOutOfBoundsException e) { System.out.println("Indice fuera de rango!");
		//} catch (ArrayIndexOutOfBoundsException | StringIndexOutOfBoundsException e) { System.out.println("Indice fuera de rango!");
		} catch (IndexOutOfBoundsException e) 		{ System.out.println("Indice fuera de rango!");
		} catch (FileNotFoundException e)			{ System.out.println("No se encuentra el archivo!");
		} catch (IOException e)						{ System.out.println("Problemas I/O");
		} catch (Exception e) 						{ System.out.println("Ocurrio un error no esperado!"); 
		}
		
		//Uso de Exceptions para validar reglas de negocio.
		Vuelo v1=new Vuelo("AER1234",100);
		Vuelo v2=new Vuelo("LAT1111",100);
		
		
		try {
			v1.venderPasajes(50);
			v2.venderPasajes(20);
			v1.venderPasajes(30);
			v2.venderPasajes(10);
			v1.venderPasajes(30); 			//Lanza una Exception
			v2.venderPasajes(10); 			//Esta venta no se realiza
		} catch (NoHayMasPasajesException e) {
			System.out.println(e);
		}
		
		//No Hacer Esto!!!!!!
		FileReader reader=null;
		try {
			reader=new FileReader("texto.txt");
			System.out.println(reader.read());
			reader.close();
		} catch (Exception e) {
			System.out.println(e);
			
		} finally {
			if(reader!=null) {
				try {
					reader.close();
				}catch(Exception e) {
					System.out.println(e);
				}
			}
		}
		
		
		//Uso de try with resources JDK 7 o sup 
		//Interface Closeable o AutoCloseable
		try (FileReader reader2=new FileReader("texto.txt")) {
			System.out.println(reader2.read());
		} catch (Exception e) {
			System.out.println(e);
		}
		
	}
}
