package ar.com.eduit.curso.java.interfaces;

public interface I_File {
	/*
	 * Interfaces en java
	 * - Todos los miembros de una interface son publicos.
	 * - Una interface no puede tener atributos no estaticos o no constantes.
	 * - Una interface no puede tener constructores.
	 * - Si puede tener atributos statics o final.
	 * - Todos los métodos son abstractos.
	 * - Una clase puede implementar muchas interfaces.
	 * - Una interface puede ser implementada por muchas clases.
	 */
	
	
	/**
	 * Escribe texto en un archivo.
	 * @param text texto a escribir en el archivo
	 */
	void setText(String text);
	
	/**
	 * Lee el archivo
	 * @return retorna el texto de un archivo
	 */
	String getText();
	
	//Interfaces en java 8
	//métodos default
	//Lo método default tiene cuerpo(código), como una clase puede implementar
	//muchas interfaces, se genera una forma de herencia multiple.
	public default void info() {
		System.out.println("Inteface I_File");
	}
	
	
}
