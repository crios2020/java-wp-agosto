package ar.com.eduit.curso.java.test;

import java.util.Scanner;

import ar.com.eduit.curso.java.interfaces.I_File;
import ar.com.eduit.curso.java.utils.files.FileBinary;
import ar.com.eduit.curso.java.utils.files.FileNull;
import ar.com.eduit.curso.java.utils.files.FileText;

public class TestInterfaces {
	public static void main(String[] args) throws Exception{
		I_File file=new FileNull();
		
		//file=new FileText();
		//file=new FileBinary();
		
		System.out.print("Ingrese 'FileText' o 'FileBinary' o 'FileCloud': ");
		String in=new Scanner(System.in).nextLine();
		
		//if(in.equalsIgnoreCase("FileText")) 		file=new FileText();
		//if(in.equalsIgnoreCase("FileBinary")) 	file=new FileBinary();
		
		//JDK 8
		//file=(I_File)Class.forName("ar.com.eduit.curso.java.utils.files."+in).newInstance();
		
		file=(I_File)Class
				.forName("ar.com.eduit.curso.java.utils.files."+in)
				.getConstructor()
				.newInstance();
		
		//app
		file.setText("Hola");
		System.out.println(file.getText());
		file.info();
	}
}
