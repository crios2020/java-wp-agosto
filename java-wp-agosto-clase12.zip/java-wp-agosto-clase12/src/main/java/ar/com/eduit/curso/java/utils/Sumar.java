package ar.com.eduit.curso.java.utils;

public class Sumar {
    public int sumar(int nro1, int nro2){
        return nro1+nro2;
    }
}
