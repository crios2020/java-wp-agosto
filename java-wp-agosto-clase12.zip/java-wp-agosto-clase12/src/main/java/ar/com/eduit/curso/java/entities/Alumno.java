package ar.com.eduit.curso.java.entities;

public class Alumno {
    
    private int id;
    private String nombre;
    private String apellido;
    private int edad;
    private int idCurso;

    public Alumno() {
    }

    public Alumno(String nombre, String apellido, int edad, int idCurso) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.idCurso = idCurso;
    }

    public Alumno(int id, String nombre, String apellido, int edad, int idCurso) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.idCurso = idCurso;
    }

    @Override
    public String toString() {
        return "Alumno [apellido=" + apellido + ", edad=" + edad + ", id=" + id + ", idCurso=" + idCurso + ", nombre="
                + nombre + "]";
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public int getEdad() {
        return edad;
    }

    public int getIdCurso() {
        return idCurso;
    }

}
