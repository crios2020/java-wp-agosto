package ar.com.eduit.curso.java.test;

public class TestExceptions {
	public static void main(String[] args) {
		
		//System.out.println(10/0);
		//System.out.println("Esta sentencia no se ejecuta!!!");
	
		/*
		 * 	Estructura try - catch - finally
		 * 
		 * try {							//Obligatorio
		 * 
		 * 		//Colocar aquí las sentencias que pueden arrojar una exception.
		 * 		//Estas sentencias tienen un costo mayor de hardware.
		 * 		//Si se puede ejecutar todo bien sin exceptions el bloque termina normalmente
		 * 		//Si ocurre una excpetion el bloque no termina y pasa el control al bloque catch
		 * } catch(Exception e){			//Obligatorio
		 * 		//El bloque catch se ejecuta en caso de error.
		 * 		//Se recibe como parámetro un Objeto de Exception.
		 * } finally {						//Opcional
		 * 		//Este bloque se ejecuta siémpre.
		 * 		//Las variables creadas en try o catch estan fuera de alcance(Scope)
		 * }
		 * 
		 *	//El programa termina normalmente 
		 * 
		 */
		
		try {
			System.out.println(10/1);
			System.out.println("Termina el bloque TRY!!!");
		} catch (Exception e) {
			System.out.println("Ocurrio un error!");
			System.out.println(e);
		} finally {
			System.out.println("El programa termina normalmente!");
		}
	}
}
