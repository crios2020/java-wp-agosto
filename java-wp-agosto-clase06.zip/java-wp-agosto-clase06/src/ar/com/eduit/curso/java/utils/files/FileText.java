package ar.com.eduit.curso.java.utils.files;

import ar.com.eduit.curso.java.interfaces.I_File;

public class FileText implements I_File{

	@Override
	public void setText(String text) {
		System.out.println("Escribiendo Archivo de texto!");
	}

	@Override
	public String getText() {
		return "Leyendo Archivo de texto!";
	}

}
