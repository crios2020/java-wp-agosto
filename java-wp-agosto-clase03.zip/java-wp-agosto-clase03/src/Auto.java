
//Declaración de Clase
public class Auto {
    
    //Atributos
    String marca;
    String modelo;
    String color;
    boolean aireAcondicionado;
    int velocidad;

    /**
     * Este método fue deprecado por Carlos el 26/8/2022 por resultar inseguro
     * usar en su reemplazo  
     * Auto(String marca, String modelo, String color, boolean aireAcondicionado)
     */
    @Deprecated
    Auto(){} //constructor vacio
    
    //Método constructor
    Auto(String marca, String modelo, String color, boolean aireAcondicionado){
    	this.marca=marca;
    	this.modelo=modelo;
    	this.color=color;
    	this.aireAcondicionado=aireAcondicionado;
    }
    
    //Métodos
    void acelerar(){
        velocidad+=10;
        //regla de negocio, control de velocidad máxima
        if(velocidad>100) velocidad=100;
    }
    
    //Método sobrecargado
    /**
     * Acelera el vehiculo
     * @param kilometros cantidad de kilometros a acelerar
     */
    void acelerar(int kilometros) {
    	velocidad+=kilometros;
    	if(velocidad>100) velocidad=100;
    }

    void frenar(){
        velocidad-=10;
    }

    void imprimirVelocidad() {
    	System.out.println(velocidad);
    }
    
    //método con devolución de valor
    int obtenerVelocidad() {
    	return velocidad;
    }
    
    String getEstado() {
    	return marca+" "+modelo+" "+color+" "+velocidad+" "+aireAcondicionado;
    }
    
    @Override						//Anotation			JDK 5 
    public String toString() {
    	return marca+" "+modelo+" "+color+" "+velocidad+" "+aireAcondicionado;
    }
    
}//end class
