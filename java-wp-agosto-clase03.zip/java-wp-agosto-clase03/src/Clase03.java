import javax.swing.JOptionPane;

public class Clase03 {

	//atributo de clase
	static int atributo;
	
	public static void main(String[] args) {
		/*
		 * Clase 03
		 * 
		 * Paradigma de Programación Orientada a Objetos
		 * 
		 * Que es una clase? Una clase es una idea generica y sustantiva, Se detectan como sustantivos.
		 * 
		 * Clases en Java: las clases en java se representan como objetos de la clase java.lang.Class
		 * 
		 * Que son los atributos? Son adjetivos que describen a la clase, son variables contenidas dentro 
		 * 	de la clase, tienen un tipo de datos asignado. Las clases declaran atributos y los objetos le completan
		 *  el estado a los atributos
		 * 
		 * Atributos en Java: los atributos en java se representan como objetos de la clase java.lang.reflect.Field
		 * 
		 * Que son los métodos en Java? Son acciones que realiza la clase, se detectan como verbos. Pueden tener 
		 * parámetros de entrada y de salida.
		 * 
		 * Métodos en Java: los métodos se representan como objetos de la clase java.lang.reflect.Method
		 * 
		 * Que son los objetos: son instancia de una clase, representa una situación en particular
		 * con un estado propio.
		 * 
		 * Sobrecarga de métodos: se produce cuando dos métodos tienen el mismo nombre, dentro de una
		 * 	misma clase. Los métodos con el mismo nombre, deben diferir en la firma de parámetros de entrada.
		 * 
		 * Métodos constructores: Son métodos que inicializan los objetos, tienen el mismo nombre que la 
		 *  clase, no tiene devolución de valor, se invoca automáticamente al construir un objeto.
		 *  Si la clase no tiene constructor declarado, Java crea un constructor vacio en tiempo de 
		 *  compilación.
		 *  Los constructores pueden sobrecargarse.
		 *  
		 *  Constructores en Java: los constructores en java se representan con la clase 
		 *  	java.lang.reflect.Constructor
		 * 
		 */

		//https://codeshare.io/QnL3Qe

		System.out.println("Hola Mundo!!");

		System.out.println("-- auto1 --");
		Auto auto1=new Auto();				// Construye la variable auto, llama al método constructor
		auto1.marca="Ford";
		auto1.modelo="Ka";
		auto1.color="Negro";
		auto1.aireAcondicionado=true;
		auto1.acelerar();		//10
		auto1.acelerar();		//20
		auto1.acelerar();		//30
		auto1.frenar();			//20
		auto1.acelerar(23); 	//43
		System.out.println(auto1.marca+" "+auto1.modelo+" "+auto1.color+" "+auto1.aireAcondicionado+" "+auto1.velocidad);
		//Los atributos tienen un proceso de inicialización automático,
		//los atributos numéricos se inicializan en 0, los atributos String se inicializan en null

		int x; //variable local, debe ser inicializada
		//System.out.println(x); //Error la variable x debe ser inicializada.
		System.out.println(atributo);

		System.out.println("-- auto2 --");
		Auto auto2=new Auto();
		auto2.marca="Fiat";
		auto2.modelo="Toro";
		auto2.color="Rojo";
		auto2.aireAcondicionado=true;
		for(int a=0; a<=40; a++) auto2.acelerar();
		System.out.println(auto2.marca+" "+auto2.modelo+" "+auto2.color+" "+auto2.aireAcondicionado+" "+auto2.velocidad);
		
		auto2.imprimirVelocidad();
		int velocidad=auto2.obtenerVelocidad();
		System.out.println(velocidad);
		System.out.println(auto2.obtenerVelocidad());
		
		//JOptionPane.showMessageDialog(null, "Hola a todos!!!");
		//JOptionPane.showMessageDialog(null, "Velocidad: "+auto2.obtenerVelocidad());
		
		System.out.println(auto2.getEstado());
		//método toString()
		System.out.println(auto2.toString());
		System.out.println(auto2);
		
		System.out.println("-- auto3 --");
		Auto auto3=new Auto("Renault","Kango","Bordo",true);
		auto3.acelerar();
		System.out.println(auto3);
		
		String marca="WV";
		String modelo="Gol";
		String color="Blanco";
		boolean aireAcondicionado=true;
		
		System.out.println("-- auto4 --");
		Auto auto4=new Auto(marca, modelo, color, aireAcondicionado);
		auto4.acelerar(45);
		System.out.println(auto4);
		
		System.out.println("-- auto5 --");
		Auto auto5=new Auto();
		System.out.println(auto5);
		
		
		
		
	}//end main

}//end class
