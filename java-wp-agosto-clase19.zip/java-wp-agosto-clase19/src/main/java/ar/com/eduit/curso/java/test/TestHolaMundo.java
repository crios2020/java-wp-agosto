package ar.com.eduit.curso.java.test;

public class TestHolaMundo {

	public static void main(String[] args) {
		//Test Objetos MOCKS
		System.out.println("Hola Mundo!");
		System.out.println(System.getProperty("java.version"));
	}

}
