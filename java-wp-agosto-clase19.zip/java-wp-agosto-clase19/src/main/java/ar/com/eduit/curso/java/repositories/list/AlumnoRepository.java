package ar.com.eduit.curso.java.repositories.list;

import java.util.ArrayList;
import java.util.List;

import ar.com.eduit.curso.java.entities.Alumno;
import ar.com.eduit.curso.java.repositories.interfaces.I_AlumnoRepository;

/**
 * Implementación que trabaja con una collection en RAM
 */
public class AlumnoRepository implements I_AlumnoRepository{
    private List<Alumno> list=new ArrayList();
    private int id=0;

    @Override
    public void save(Alumno alumno) {
        id++;
        alumno.setId(id);
        list.add(alumno);
    }

    @Override
    public void remove(Alumno alumno) {
        list.remove(alumno);
    }

    @Override
    public void update(Alumno alumno) {
       
    }

    @Override
    public List<Alumno> getAll() {
        return list;
    }
}
