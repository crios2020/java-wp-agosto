package ar.com.eduit.curso.java.connectors;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.sql.Connection;
import java.sql.ResultSet;

import org.junit.jupiter.api.Test;

public class TestConnector{
    
	private Connection conn=null;
	
	@Test
    void testGetConnection() {
		conn=Connector.getConnection();
		if(conn==null) {
			assertEquals(true, false);
		}else {
			assertEquals(true,true);
		}
    }
	
	@Test
	void testGetConnection2() {
		conn=Connector.getConnection();
		try(ResultSet rs=conn.createStatement().executeQuery("select version()")){
			if(rs.next()) {
				assertEquals(rs.getString(1).length()>3, true);
			} else {
				assertEquals(true, false);
			}
		}catch(Exception e) {
			assertEquals(true, false);
		}
	}
	
	

}