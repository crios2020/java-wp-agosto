
public class Clase02 {
	public static void main(String[] args) {
		// Mostrar tipo de datos primitivos

		// Lenguajes de tipado fuerte Java, C, C++, C#, Visual Basic
		// Lenguajes de tipado debil PHP, Python, Javascript

		// Tipo de datos enteros

		// Tipo de datos boolean true 1 false 0 1 bytes
		boolean bo = true;
		System.out.println(bo);
		bo = false;
		System.out.println(bo);

		/*
		 * 0 |--------|
		 * 
		 */

		// Tipo de datos byte 1 byte signed
		byte by = -128;
		System.out.println(by);

		/*
		 * |--------|--------| -128 0 127
		 */

		// Tipo de datos short 2 bytes 65536 signed
		short sh = 32000;
		System.out.println(sh);

		// Tipo de datos int 4 bytes 2000M
		int in = 2000000000;
		System.out.println(in);

		// Tipo de datos long 8 bytes
		long lo = 3000000000000000000L;
		System.out.println(lo);

		// Clase BigDecimal

		// Tipo de datos char 2 bytes 65536 unsigned
		char ch = 65;
		System.out.println(ch);
		ch += 32;
		System.out.println(ch);

		ch = 'h';
		System.out.println(ch);

		// Tipo de datos punto flotante

		// Tipo de datos float 32 bits
		float fl = 9.55f;
		System.out.println(fl);

		// Tipo de datos double 64 bits
		double dl = 9.55;
		System.out.println(dl);

		fl = 10;
		dl = 10;

		System.out.println(fl / 3);
		System.out.println(dl / 3);

		fl = 100;
		dl = 100;

		System.out.println(fl / 3);
		System.out.println(dl / 3);

		// Clase String
		String st = "hola";
		System.out.println(st);

		// Estructuras Lógica
		String cadena = "Esto es una cadena de texto!";
		System.out.println(cadena);

		// System.out.println(cadena.value[0]);
		System.out.println(cadena.charAt(0));

		// Recorrer el String cadena
		for (int a = 0; a < cadena.length(); a++) {
			System.out.print(cadena.charAt(a));
		}
		System.out.println();

		// Imprimir cadena todo en mayúsculas
		for (int a = 0; a < cadena.length(); a++) {
			char car = cadena.charAt(a);
			if (car >= 97 && car <= 122) car -= 32;
			System.out.print(car);
		}
		System.out.println();
		
		// Operador Ternario ?
		for (int a = 0; a < cadena.length(); a++) {
			char car = cadena.charAt(a);
			System.out.print((car >= 97 && car <= 122)?car-=32:car);
		}
		System.out.println();
		
		// Imprimir cadena todo en minúsculas
		for (int a=0; a<cadena.length(); a++) {
			char car = cadena.charAt(a);
			System.out.print((car>=65 && car <=90)?car+=32:car);
		}
		System.out.println();
		
		System.out.println(cadena.toLowerCase());
		System.out.println(cadena.toUpperCase());
		
		

	}
}
