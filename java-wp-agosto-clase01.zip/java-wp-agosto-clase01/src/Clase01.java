import javax.swing.JOptionPane;

/*
 * Curso: 	Java Standard Web Programming 40 hs
 * Días:	Miércoles y Viernes 10:00 a 12:00 hs
 * Profe:	Carlos Rios		c.rios@educacionit.com
 * 
 * Materiales:	
 * 			alumni.educacionit.com
 * 				user: email
 * 				pass: dni
 * 
 * 			github: https://github.com/crios2020/java-wp-agosto
 * 
 * Software: 
 * 			JDK 17 LTS
 * 			IDE
 * 
 * JDK (Java Development Kit - Kit de Desarrollo Java)
 * 
 * LTS: Long Term Support 8 años
 * 
 * IDE: Eclipse - Spring Tools Suite - VsCode - Netbeans
 */

/* Bloque de Comentarios */
// Linea de comentarios
//TODO Tarea pendiente
/**
 * Comentarios Java DOC, Este comentario debe colocarse delante de la declaración de clases o métodos.
 * Este comentario tiene la posibilidad de leerse por fuera del archivo binario.
 * @author carlos
 *
 */
public class Clase01 {
	
	public static final String ANSI_BLACK = "\u001B[30m";
	public static final String ANSI_RED = "\u001B[31m";
	public static final String ANSI_GREEN = "\u001B[32m";
	public static final String ANSI_YELLOW = "\u001B[33m";
	public static final String ANSI_BLUE = "\u001B[34m";
	public static final String ANSI_PURPLE = "\u001B[35m";
	public static final String ANSI_CYAN = "\u001B[36m";
	public static final String ANSI_WHITE = "\u001B[37m";
	public static final String ANSI_RESET = "\u001B[0m";
	
	/**
	 * Punto de entrada del Proyecto
	 * @param args argumentos que ingresan desde consola.
	 */
	public static void main(String[] args) {
		System.out.println("Hola Mundo!");
		//JOptionPane.showMessageDialog(null, "Hola a todos");
		
		System.out.println("Cantidad de párametros: "+args.length);
		for(int i=0; i<args.length; i++) {
			System.out.println(args[i]);
		}
		
		// 2+2=4
		if(sumar(2,2)==4) 		System.out.println(ANSI_GREEN+"OK 2+2=4"+ANSI_RESET);
		else					System.out.println(ANSI_RED+"Error 2+2=4"+ANSI_RESET);
		
		// 0+8=8
		if(sumar(0,8)==8) 		System.out.println(ANSI_GREEN+"OK 0+8=8"+ANSI_RESET);
		else					System.out.println(ANSI_RED+"Error 0+8=8"+ANSI_RESET);
		
		// -10-10=-20
		if(sumar(-10,-10)==-20)	System.out.println(ANSI_GREEN+"OK -10+-10=-20"+ANSI_RESET);
		else					System.out.println(ANSI_RED+"Error -10+-10=-20"+ANSI_RESET);
		
		//TODO Mostrar tipo de datos primitivos
		
		//Lenguajes de tipado fuerte	Java, C, C++, C#, Visual Basic
		//Lenguajes de tipado debil		PHP, Python, Javascript
		
		//Tipo de datos enteros
		
		//Tipo de datos boolean		true 1	false 0		1 bytes
		boolean bo=true;
		System.out.println(bo);
		bo=false;
		System.out.println(bo);
		
		/*
		 * 		 0
		 * 		|--------|
		 * 
		 */
		
		
		//TODO Estructuras Logicas
		
		
		
	}
	
	/**
	 * Este método suma dos números 
	 * @param nro1 termino 1
	 * @param nro2 termino 2
	 * @return retorna la suma de los dos párametros de entrada
	 */
	public static int sumar(int nro1, int nro2) {
		//sumar los dos parametros
		return nro1+nro2;
	}
}
