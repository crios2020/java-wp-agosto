package ar.com.eduit.curso.java.util.math;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class CalculadoraTest {

    @Test
    void test1(){
        //prueba OK
        assertEquals(2+2, 4);
    }

    @Test
    void test2(){
        //Prueba erronea
        //assertEquals(10+5, 14);
    }

    Calculadora calculadora=new Calculadora();
    /**
     * Prueba de sumar números enteros
     */
    @Test
    void testSumarEnteros1() {
 
        assertEquals(calculadora.sumar(2, 2), 4);
    }

    @Test
    void testSumarEnteros2() {

        assertEquals(calculadora.sumar(20, 60), 80);
    }

    @Test
    void testSumarEnterosnegativos() {

        assertEquals(calculadora.sumar(-2, -2), -4);
 
    }

    @Test
    void testSumarDouble() {

        assertEquals(calculadora.sumar(5.4, 2.1), 7.5);

    }

    @Test
    void testSumarElementoNeutro1() {

        assertEquals(calculadora.sumar(2, 0), 2);

    }

    @Test
    void testSumarElementoNeutro2() {

        assertEquals(calculadora.sumar(0, 2), 2);

    }

    @Test
    void testSumarElementoNeutro3() {

        assertEquals(calculadora.sumar(0, 0), 0);
 
    }

    @Test
    void testSumarDesbordamiento() {

        assertEquals(calculadora.sumar(2000000000, 2000000000), 4000000000l);

    }

    @Test
    void testRestar() {

    }

    @Test
    void testDividir() {

    }

    @Test
    void testMultiplicar() {

    }




}
