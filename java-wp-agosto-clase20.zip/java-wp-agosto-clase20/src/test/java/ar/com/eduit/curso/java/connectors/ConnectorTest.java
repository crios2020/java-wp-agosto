package ar.com.eduit.curso.java.connectors;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.sql.Connection;
import java.sql.ResultSet;

import org.junit.jupiter.api.Test;

public class ConnectorTest {
    @Test
    void testGetConnectionOK() {
        try (ResultSet rs=Connector.getConnection().createStatement().executeQuery("select version()")) {
            if(rs.next() && rs.getString(1).length()>=3){
                assertEquals(true, true);
            }else{
                assertEquals(true, false);
            }
        } catch (Exception e) {
            assertEquals(true, false);
        }
    }

    @Test
    void testGetConnectionTime() {

    }
}
