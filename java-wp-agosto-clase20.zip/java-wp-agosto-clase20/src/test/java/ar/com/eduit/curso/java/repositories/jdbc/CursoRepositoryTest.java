package ar.com.eduit.curso.java.repositories.jdbc;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import ar.com.eduit.curso.java.connectors.Connector;
import ar.com.eduit.curso.java.entities.Curso;
import ar.com.eduit.curso.java.enums.Dia;
import ar.com.eduit.curso.java.enums.Turno;
import ar.com.eduit.curso.java.repositories.interfaces.I_CursoRepository;

public class CursoRepositoryTest {
    @Test
    void testSave() {
        I_CursoRepository cursoRepository=new CursoRepository(Connector.getConnection());
        Curso curso=new Curso("Jardineria","Marioti",Dia.MARTES,Turno.MAÑANA);
        cursoRepository.save(curso);
        int id1=curso.getId();
        assertEquals(id1>0, true);
        curso=new Curso("Jardineria","Marioti",Dia.MARTES,Turno.MAÑANA);
        cursoRepository.save(curso);
        int id2=curso.getId();
        assertEquals(id1+1, id2);

        curso=cursoRepository.getById(id2);
        assertEquals(curso.getTitulo(),"Jardineria");
        assertEquals(curso.getProfesor(),"Marioti");
        assertEquals(curso.getDia(), Dia.MARTES);
        assertEquals(curso.getTurno(), Turno.MAÑANA);
    }
}
