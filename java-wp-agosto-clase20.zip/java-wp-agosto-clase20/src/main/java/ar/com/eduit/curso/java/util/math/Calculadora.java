package ar.com.eduit.curso.java.util.math;

public class Calculadora {
    public double sumar(double nro1, double nro2){
        //TODO realizar la suma,
        return nro1+nro2;
    }

    public double restar(double nro1, double nro2){
        //TODO realizar la resta,
        return 0;
    }

    public double dividir(double nro1, double nro2){
        //TODO realizar la división,
        return 0;
    }

    public double multiplicar(double nro1, double nro2){
        //TODO realizar la multiplicar,
        return 0;
    }
}
