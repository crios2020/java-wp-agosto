package ar.com.eduit.curso.java.repositories.list;

public class AlumnoRepositoryFactory {
    private static AlumnoRepository ar=new AlumnoRepository();
    private AlumnoRepositoryFactory(){}
    public static AlumnoRepository getAlumnoRepository(){
        return ar;
    }
}
