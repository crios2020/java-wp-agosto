package ar.com.eduit.curso.java.repositories.list;

import java.util.ArrayList;
import java.util.List;

import ar.com.eduit.curso.java.entities.Curso;
import ar.com.eduit.curso.java.repositories.interfaces.I_CursoRepository;

/**
 * Implementación que trabaja con una collection en RAM
 */
public class CursoRepository implements I_CursoRepository {
    List<Curso>list=new ArrayList();
    private int id=0;

    @Override
    public void save(Curso curso) {
        id++;
        curso.setId(id);
        list.add(curso);
    }

    @Override
    public void remove(Curso curso) {
        list.remove(curso);
    }

    @Override
    public void update(Curso curso) {
        
    }

    @Override
    public List<Curso> getAll() {
        return list;
    }
}
