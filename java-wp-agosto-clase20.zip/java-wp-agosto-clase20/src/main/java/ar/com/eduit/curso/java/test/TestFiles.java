package ar.com.eduit.curso.java.test;

import java.time.LocalTime;
import java.util.List;

import ar.com.eduit.curso.java.util.files.FileText;
import ar.com.eduit.curso.java.util.files.I_File;

public class TestFiles {
    public static void main(String[] args) {
        //String file="c:/texto.txt";             //ruta es relativa al hdd
        String file="texto.txt";                  //ruta es relativa al proyecto
        I_File fileText=new FileText(file);
        fileText.setText("Hola a todos!!!\n");   
        fileText.append("Curso de java!!!\n");
        fileText.addLine("Hoy es Miércoles!!!");    
        fileText.addLines(List.of("Primavera","Verano","Invierno","Otoño"));   
        fileText.addLines(List.of(
                                    "Lunes",
                                    "Martes",
                                    "Miércoles",
                                    "Jueves",
                                    "Viernes",
                                    "Sábado",
                                    "Domingo",
                                    "Lunes",
                                    "Otoño"
                                    ));  

        fileText.remove("Invierno");

        //System.out.println(fileText.getText());
        //fileText.print();
        fileText.getAll().forEach(System.out::println);
        //fileText.getLikeFilter("es").forEach(System.out::println);
        //fileText.getLinkedHashSet().forEach(System.out::println);
        //fileText.getTreeSet().forEach(System.out::println);
        //fileText.getSortedLines().forEach(System.out::println);
        //fileText.getReversedSortedLines().forEach(System.out::println);

        //String[] vectorlinea="campo 1~campo 2~campo 3".split("~");
        //for(String valor:vectorlinea) System.out.println(valor);
        
        String texto="";
        StringBuffer sb=new StringBuffer();
        System.out.println(LocalTime.now());
        for(int a=0;a<=20000000; a++){
            //texto+="x";
            sb.append("x");
        }
        System.out.println(LocalTime.now());
        
        /*
        file="datos.txt";
        fileText=new FileText(file);
        fileText.getAll().forEach(linea->{
            String[] vectorlinea=linea.split("~");
            System.out.println(vectorlinea[0]);
            if(vectorlinea[1].length()==8){
                System.out.println("longitud OK");
                try {
                    Integer.parseInt(vectorlinea[1]);
                    //Double.parseDouble(vectorlinea[1]);
                    System.out.println("Es entero!");
                } catch (NumberFormatException e) {
                    System.out.println("No es entero!");
                }
            }else{
                System.out.println("longitud Error!");
            }
        });
        */


    }
}
